// supabase/functions/stripe-webhook/index.ts
// 二重処理対策（Idempotency）強化版
// - event.id による重複排除
// - DB関数による原子的処理
// - constructEventAsync 使用（Deno対応）

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14.14.0?target=deno'

// Stripe クライアント初期化
const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') ?? '', {
  apiVersion: '2023-10-16',
  httpClient: Stripe.createFetchHttpClient(),
})

const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET') ?? ''
const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? ''
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''

serve(async (req: Request): Promise<Response> => {
  const signature = req.headers.get('stripe-signature')

  if (!signature) {
    console.error('No stripe-signature header')
    return new Response(JSON.stringify({ error: 'No signature' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  const body = await req.text()
  let event: Stripe.Event

  try {
    // Deno対応: constructEventAsync を使用
    event = await stripe.webhooks.constructEventAsync(
      body,
      signature,
      webhookSecret
    )
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error'
    console.error('Webhook signature verification failed:', errorMessage)
    return new Response(
      JSON.stringify({ error: `Webhook Error: ${errorMessage}` }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    )
  }

  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  console.log(`Received event: ${event.type}, id: ${event.id}`)

  try {
    // ============================================
    // イベントタイプ別処理
    // 確定トリガーは checkout.session.completed のみ
    // ============================================
    switch (event.type) {
      case 'checkout.session.completed':
        // ★ 確定処理（唯一のトリガー）
        await handleCheckoutCompleted(event, supabase)
        break

      case 'payment_intent.succeeded':
        // 補助ログのみ（checkout.session.completed で確定済みのはず）
        console.log(`payment_intent.succeeded: ${(event.data.object as Stripe.PaymentIntent).id} - No action needed`)
        break

      case 'charge.succeeded':
        // 補助ログのみ
        console.log(`charge.succeeded: ${(event.data.object as Stripe.Charge).id} - No action needed`)
        break

      case 'account.updated':
        await handleAccountUpdated(event, supabase)
        break

      case 'charge.refunded':
        await handleChargeRefunded(event, supabase)
        break

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return new Response(JSON.stringify({ received: true, event_id: event.id }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    })
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error'
    console.error(`Error processing ${event.type}:`, errorMessage)

    // エラーでも200を返す（Stripeの無限リトライを防ぐ）
    // ただし、リトライが必要な一時的エラーの場合は500を返すことも検討
    return new Response(
      JSON.stringify({ error: errorMessage, event_id: event.id }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    )
  }
})

// ============================================
// checkout.session.completed ハンドラー
// ★ これが唯一の確定トリガー
// ============================================
async function handleCheckoutCompleted(
  event: Stripe.Event,
  supabase: ReturnType<typeof createClient>
) {
  const session = event.data.object as Stripe.Checkout.Session
  const eventId = event.id

  console.log(`Processing checkout.session.completed: session=${session.id}, event=${eventId}`)

  // 1. まず event.id の重複チェック（最速で弾く）
  const { data: existingEvent } = await supabase
    .from('stripe_webhook_events')
    .select('id')
    .eq('event_id', eventId)
    .maybeSingle()

  if (existingEvent) {
    console.log(`Event ${eventId} already processed, skipping`)
    return
  }

  // 2. order_id を特定
  let orderId = session.metadata?.order_id

  if (!orderId) {
    console.log('No order_id in metadata, looking up by session_id')

    const { data: order } = await supabase
      .from('orders')
      .select('id')
      .eq('stripe_session_id', session.id)
      .maybeSingle()

    if (!order) {
      console.error('Order not found for session:', session.id)
      // イベントは記録しておく（調査用）
      await recordEvent(supabase, eventId, event.type, { error: 'order_not_found', session_id: session.id })
      return
    }

    orderId = order.id
  }

  // 3. DB関数で原子的に処理（競合に強い）
  const { data: result, error } = await supabase.rpc('process_checkout_completed', {
    p_event_id: eventId,
    p_session_id: session.id,
    p_payment_intent_id: session.payment_intent as string,
    p_order_id: orderId,
  })

  if (error) {
    console.error('Error in process_checkout_completed:', error)

    // DB関数が存在しない場合のフォールバック
    if (error.message.includes('does not exist')) {
      console.log('Falling back to direct processing')
      await handleCheckoutCompletedFallback(eventId, session, orderId, supabase)
      return
    }

    throw error
  }

  console.log('Process result:', JSON.stringify(result))

  if (result?.status === 'processed') {
    console.log(`Order ${orderId} successfully processed - amount: ${result.amount}, platform_fee: ${result.platform_fee}, author: ${result.author_amount}, affiliate: ${result.affiliate_amount}`)
  } else if (result?.status === 'already_processed') {
    console.log(`Order ${orderId} was already processed: ${result.reason}`)
  } else {
    console.log(`Unexpected result:`, result)
  }
}

// ============================================
// フォールバック処理（DB関数がない場合）
// ============================================
async function handleCheckoutCompletedFallback(
  eventId: string,
  session: Stripe.Checkout.Session,
  orderId: string,
  supabase: ReturnType<typeof createClient>
) {
  // イベント記録を試みる（重複なら失敗）
  const { error: eventError } = await supabase
    .from('stripe_webhook_events')
    .insert({ event_id: eventId, event_type: 'checkout.session.completed' })

  if (eventError) {
    if (eventError.code === '23505') { // unique_violation
      console.log(`Event ${eventId} already recorded, skipping`)
      return
    }
    // stripe_webhook_events テーブルが存在しない場合は続行
    console.warn('Could not record event:', eventError.message)
  }

  // 注文の状態チェック
  const { data: existingOrder } = await supabase
    .from('orders')
    .select('id, status, processed_event_id')
    .eq('id', orderId)
    .single()

  if (existingOrder?.status === 'paid') {
    console.log(`Order ${orderId} already paid`)
    return
  }

  // 記事情報を取得
  const { data: orderData } = await supabase
    .from('orders')
    .select('article_id, amount, affiliate_user_id')
    .eq('id', orderId)
    .single()

  // アフィリエイト率を取得
  let affiliateRate = 0
  if (orderData?.article_id) {
    const { data: article } = await supabase
      .from('articles')
      .select('affiliate_rate')
      .eq('id', orderData.article_id)
      .single()
    affiliateRate = article?.affiliate_rate || 0
  }

  // 分配額を計算（端数処理）
  const amount = orderData?.amount || 0
  const platformFee = Math.floor(amount * 0.15)
  const afterPlatformFee = amount - platformFee
  const affiliateAmount = orderData?.affiliate_user_id && affiliateRate > 0
    ? Math.floor(afterPlatformFee * affiliateRate / 100)
    : 0
  const authorAmount = afterPlatformFee - affiliateAmount

  // 合計チェック（デバッグ用）
  const total = platformFee + authorAmount + affiliateAmount
  if (total !== amount) {
    console.error(`Distribution mismatch! amount=${amount}, total=${total}`)
  }

  // 注文を更新
  const { error: updateError } = await supabase
    .from('orders')
    .update({
      status: 'paid',
      stripe_session_id: session.id,
      stripe_payment_intent_id: session.payment_intent as string,
      paid_at: new Date().toISOString(),
      processed_event_id: eventId,
      purchase_affiliate_rate: affiliateRate,
      platform_fee: platformFee,
      author_amount: authorAmount,
      affiliate_amount: affiliateAmount,
      transfer_status: 'ready',
      updated_at: new Date().toISOString(),
    })
    .eq('id', orderId)
    .eq('status', 'pending') // ★ pending の場合のみ更新（競合防止）

  if (updateError) {
    console.error('Error updating order:', updateError)
    throw updateError
  }

  console.log(`Order ${orderId} processed (fallback) - amount: ${amount}, platform_fee: ${platformFee}, author: ${authorAmount}, affiliate: ${affiliateAmount}`)
}

// ============================================
// イベント記録用ヘルパー
// ============================================
async function recordEvent(
  supabase: ReturnType<typeof createClient>,
  eventId: string,
  eventType: string,
  payload?: Record<string, unknown>
) {
  try {
    await supabase
      .from('stripe_webhook_events')
      .insert({
        event_id: eventId,
        event_type: eventType,
        payload: payload || null,
      })
  } catch (e) {
    console.warn('Failed to record event:', e)
  }
}

// ============================================
// account.updated ハンドラー
// ============================================
async function handleAccountUpdated(
  event: Stripe.Event,
  supabase: ReturnType<typeof createClient>
) {
  const account = event.data.object as Stripe.Account
  const eventId = event.id

  console.log(`Processing account.updated: ${account.id}, event=${eventId}`)

  // Connect関連は冪等性の問題が少ないが、一応イベント記録
  await recordEvent(supabase, eventId, event.type)

  const status = account.details_submitted ? 'active' : 'onboarding'

  const { error } = await supabase
    .from('profiles')
    .update({
      stripe_account_status: status,
      stripe_payouts_enabled: account.payouts_enabled ?? false,
      stripe_charges_enabled: account.charges_enabled ?? false,
      stripe_onboarding_completed_at: account.details_submitted
        ? new Date().toISOString()
        : null,
    })
    .eq('stripe_account_id', account.id)

  if (error) {
    console.error('Error updating account:', error)
    throw error
  }

  console.log(`Account ${account.id} updated: payouts_enabled=${account.payouts_enabled}`)
}

// ============================================
// charge.refunded ハンドラー
// ============================================
async function handleChargeRefunded(
  event: Stripe.Event,
  supabase: ReturnType<typeof createClient>
) {
  const charge = event.data.object as Stripe.Charge
  const eventId = event.id

  console.log(`Processing charge.refunded: ${charge.id}, event=${eventId}`)

  // イベント重複チェック
  const { data: existingEvent } = await supabase
    .from('stripe_webhook_events')
    .select('id')
    .eq('event_id', eventId)
    .maybeSingle()

  if (existingEvent) {
    console.log(`Event ${eventId} already processed, skipping`)
    return
  }

  await recordEvent(supabase, eventId, event.type)

  const paymentIntentId = charge.payment_intent
  if (!paymentIntentId || typeof paymentIntentId !== 'string') {
    console.log('No payment_intent in charge')
    return
  }

  const { data: order } = await supabase
    .from('orders')
    .select('id, status')
    .eq('stripe_payment_intent_id', paymentIntentId)
    .maybeSingle()

  if (!order) {
    console.log('Order not found for refund')
    return
  }

  if (order.status === 'refunded') {
    console.log('Order already refunded')
    return
  }

  const newStatus = charge.refunded ? 'refunded' : 'partially_refunded'

  await supabase
    .from('orders')
    .update({
      status: newStatus,
      refunded_at: new Date().toISOString(),
    })
    .eq('id', order.id)

  console.log(`Order ${order.id} status updated to: ${newStatus}`)
}
