// supabase/functions/create-checkout-session/index.ts
// アフィリエイト対応版

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14.14.0?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2023-10-16',
  httpClient: Stripe.createFetchHttpClient(),
})

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // アフィリエイトIDも受け取れるように拡張
    const { article_id, affiliate_user_id } = await req.json()

    if (!article_id) {
      return new Response(
        JSON.stringify({ error: 'article_id is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Authorization ヘッダーからトークン取得
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authorization required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey)
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // 記事取得（アフィリエイト情報も含める）
    const { data: article, error: articleError } = await supabase
      .from('articles')
      .select('id, title, price, author_id, slug, status, affiliate_enabled, affiliate_rate')
      .eq('id', article_id)
      .single()

    if (articleError || !article) {
      return new Response(
        JSON.stringify({ error: 'Article not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // published以外は弾く
    if (article.status !== 'published') {
      return new Response(
        JSON.stringify({ error: 'Article not available' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // 自分の記事は購入不可
    if (article.author_id === user.id) {
      return new Response(
        JSON.stringify({ error: 'Cannot purchase own article' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // 既に購入済みチェック
    const { data: existingPaid } = await supabase
      .from('orders')
      .select('id')
      .eq('buyer_id', user.id)
      .eq('article_id', article_id)
      .eq('status', 'paid')
      .maybeSingle()

    if (existingPaid) {
      return new Response(
        JSON.stringify({ error: 'Already purchased' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // アフィリエイトユーザーの検証
    let validAffiliateUserId: string | null = null
    if (affiliate_user_id && article.affiliate_enabled) {
      // アフィリエイターが存在し、自分でも作者でもないことを確認
      if (affiliate_user_id !== user.id && affiliate_user_id !== article.author_id) {
        const { data: affiliateProfile } = await supabase
          .from('profiles')
          .select('id')
          .eq('id', affiliate_user_id)
          .single()

        if (affiliateProfile) {
          validAffiliateUserId = affiliate_user_id
        }
      }
    }

    // orders に pending で insert
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        buyer_id: user.id,
        article_id: article.id,
        author_id: article.author_id,
        affiliate_user_id: validAffiliateUserId, // アフィリエイトユーザーID
        amount: article.price,
        status: 'pending',
        payment_provider: 'stripe',
      })
      .select('id')
      .single()

    if (orderError || !order) {
      console.error('Order insert error:', orderError)
      return new Response(
        JSON.stringify({ error: 'Failed to create order' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // サイトURL取得
    const origin = req.headers.get('Origin') || req.headers.get('Referer') || ''
    const siteUrl = origin ? new URL(origin).origin : 'https://graymall.jp'

    // Stripe Checkout Session 作成
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'jpy',
          product_data: { name: article.title },
          unit_amount: article.price,
        },
        quantity: 1,
      }],
      mode: 'payment',
      success_url: `${siteUrl}/articles/${article.slug}?payment=success`,
      cancel_url: `${siteUrl}/articles/${article.slug}?payment=cancelled`,
      metadata: {
        order_id: order.id,
        article_id: article.id,
        buyer_user_id: user.id,
        affiliate_user_id: validAffiliateUserId || '', // アフィリエイトIDもmetadataに
      },
      expires_at: Math.floor(Date.now() / 1000) + 30 * 60,
    })

    // stripe_session_id 保存
    await supabase
      .from('orders')
      .update({ stripe_session_id: session.id })
      .eq('id', order.id)

    return new Response(
      JSON.stringify({ url: session.url }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (err) {
    console.error('Error:', err)
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
