// src/pages/ArticleDetail.tsx
import { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { checkArticleAccess } from '../lib/articleAccess';
import Layout from '../components/Layout';
import type { Database } from '../lib/database.types';
import { Lock, ShoppingCart, CheckCircle, Loader2, Share2, Copy } from 'lucide-react';

type Article = Database['public']['Tables']['articles']['Row'] & {
  users?: { display_name: string | null; email: string };
  primary_category?: { id: string; name: string } | null;
};

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;

export default function ArticleDetail() {
  const { slug } = useParams();
  const [searchParams] = useSearchParams();
  const { user, session, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [article, setArticle] = useState<Article | null>(null);
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [copied, setCopied] = useState(false);

  // アフィリエイトリファラルID（URLの?ref=xxx）
  const affiliateUserId = searchParams.get('ref');

  // 決済成功で戻ってきた場合
  useEffect(() => {
    if (searchParams.get('payment') === 'success') {
      setPaymentSuccess(true);
      const timer = setTimeout(() => {
        window.location.href = window.location.pathname;
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [searchParams]);

  // 記事読み込み
  useEffect(() => {
    loadArticle();
  }, [slug, user, authLoading]);

  const loadArticle = async () => {
    // 認証情報のロードが完了するまで待機
    if (authLoading) {
      return;
    }

    if (!slug) {
      setLoading(false);
      setNotFound(true);
      return;
    }

    setLoading(true);
    setNotFound(false);

    try {
      const { data, error } = await supabase
        .from('articles')
        .select(`
          *,
          users:author_id (display_name, email),
          primary_category:primary_category_id (id, name)
        `)
        .eq('slug', slug)
        .eq('status', 'published')
        .maybeSingle();

      if (error) {
        console.error('Article fetch error:', error);
        setNotFound(true);
        setLoading(false);
        return;
      }

      if (!data) {
        setNotFound(true);
        setLoading(false);
        return;
      }

      setArticle(data as Article);

      // 購入済み判定（認証済みの場合のみ）
      if (user) {
        const access = await checkArticleAccess(user.id, data);
        setHasAccess(access);
      } else {
        setHasAccess(false);
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async () => {
    if (!user || !session) {
      // ログイン後に戻ってこれるようにリファラルも保持
      const currentUrl = window.location.pathname + window.location.search;
      navigate(`/signin?redirect=${encodeURIComponent(currentUrl)}`);
      return;
    }
    if (!article) return;

    setPurchasing(true);

    try {
      const res = await fetch(
        `${SUPABASE_URL}/functions/v1/create-checkout-session`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            article_id: article.id,
            // アフィリエイトリファラルIDを渡す（有効な場合のみ）
            affiliate_user_id: affiliateUserId || undefined,
          }),
        }
      );

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to create checkout session');
      }

      window.location.href = data.url;

    } catch (err: any) {
      console.error('Purchase error:', err);
      alert(err.message || '購入処理中にエラーが発生しました');
      setPurchasing(false);
    }
  };

  // アフィリエイトリンクのコピー
  const copyAffiliateLink = async () => {
    if (!user || !article) return;

    const affiliateUrl = `${window.location.origin}/articles/${article.slug}?ref=${user.id}`;
    try {
      await navigator.clipboard.writeText(affiliateUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Copy failed:', err);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
        </div>
      </Layout>
    );
  }

  if (notFound || !article) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">記事が見つかりません</h1>
          <p className="text-gray-600">この記事は存在しないか、まだ公開されていません。</p>
        </div>
      </Layout>
    );
  }

  if (paymentSuccess) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
          <CheckCircle className="w-16 h-16 text-green-500" />
          <div className="text-xl font-bold text-gray-900">購入が完了しました</div>
          <div className="text-gray-600">ページを更新しています...</div>
          <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
        </div>
      </Layout>
    );
  }

  // 価格が0円または設定されていなければ無料記事
  const isFree = !article.price || article.price === 0;

  // アフィリエイトが有効か
  const canAffiliate = article.affiliate_enabled && article.affiliate_rate && article.affiliate_rate > 0;

  return (
    <Layout>
      <article className="max-w-4xl mx-auto px-4 py-8">
        {article.cover_image_url && (
          <img
            src={article.cover_image_url}
            alt={article.title}
            className="w-full h-96 object-cover rounded-lg mb-8"
          />
        )}

        <div className="bg-white rounded-lg shadow-sm p-6 md:p-8">
          {article.primary_category && (
            <span className="inline-block px-3 py-1 bg-gray-100 text-gray-600 text-sm rounded-full mb-4">
              {article.primary_category.name}
            </span>
          )}

          <h1 className="text-4xl font-bold text-gray-900 mb-6">{article.title}</h1>

          <div className="flex items-center justify-between mb-6 pb-6 border-b border-gray-200">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center text-lg font-medium">
                {(article.users?.display_name || article.users?.email || 'U')[0].toUpperCase()}
              </div>
              <div>
                <div className="font-medium text-gray-900">
                  {article.users?.display_name || article.users?.email?.split('@')[0]}
                </div>
                <div className="text-sm text-gray-600">
                  {new Date(article.created_at).toLocaleDateString('ja-JP')}
                </div>
              </div>
            </div>

            {/* アフィリエイト共有ボタン（購入済みかつアフィリエイト有効の場合） */}
            {user && hasAccess && canAffiliate && (
              <div className="relative">
                <button
                  onClick={() => setShowShareMenu(!showShareMenu)}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition"
                >
                  <Share2 className="w-4 h-4" />
                  <span>紹介して{article.affiliate_rate}%報酬</span>
                </button>
                {showShareMenu && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-lg border border-gray-200 p-4 z-10">
                    <p className="text-sm text-gray-600 mb-3">
                      このリンクで購入されると{article.affiliate_rate}%の報酬が得られます
                    </p>
                    <button
                      onClick={copyAffiliateLink}
                      className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                    >
                      {copied ? (
                        <>
                          <CheckCircle className="w-4 h-4" />
                          <span>コピーしました</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>リンクをコピー</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {isFree || hasAccess ? (
            <div className="prose prose-lg max-w-none">
              <div dangerouslySetInnerHTML={{
                __html: article.content
                  .replace(/<!-- paid -->/g, '')
                  .replace(/<!-- PAYWALL_BOUNDARY -->/g, '')
              }} />
            </div>
          ) : (
            <>
              <div className="prose prose-lg max-w-none mb-8">
                <div dangerouslySetInnerHTML={{ __html: article.excerpt }} />
              </div>

              {(article.content.includes('<!-- paid -->') || article.content.includes('<!-- PAYWALL_BOUNDARY -->')) && (
                <div className="prose prose-lg max-w-none mb-8">
                  <div dangerouslySetInnerHTML={{
                    __html: article.content
                      .split('<!-- paid -->')[0]
                      .split('<!-- PAYWALL_BOUNDARY -->')[0]
                  }} />
                </div>
              )}

              <div className="relative">
                <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent to-white pointer-events-none" style={{ marginTop: '-6rem' }} />
                <div className="bg-orange-50 rounded-2xl p-8 text-center border-2 border-orange-200">
                  <Lock className="w-16 h-16 mx-auto mb-4 text-orange-500" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    ここから先は有料コンテンツです
                  </h3>
                  <p className="text-gray-600 mb-6">
                    購入すると続きを読めます
                  </p>

                  {/* アフィリエイト経由の場合の表示 */}
                  {affiliateUserId && canAffiliate && (
                    <p className="text-sm text-green-600 mb-4">
                      紹介リンク経由でのご購入です
                    </p>
                  )}

                  <div className="text-4xl font-bold text-gray-900 mb-6">
                    ¥{article.price.toLocaleString()}
                  </div>
                  <button
                    onClick={handlePurchase}
                    disabled={purchasing}
                    className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-xl transition disabled:opacity-50 text-lg font-bold"
                  >
                    {purchasing ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <ShoppingCart className="w-5 h-5" />
                    )}
                    <span>{purchasing ? '処理中...' : '記事を購入する'}</span>
                  </button>
                  {!user && (
                    <p className="text-sm text-gray-600 mt-4">
                      購入するには
                      <button
                        onClick={() => navigate(`/signin?redirect=${encodeURIComponent(window.location.pathname + window.location.search)}`)}
                        className="text-blue-600 hover:underline ml-1"
                      >
                        サインイン
                      </button>
                      が必要です
                    </p>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </article>
    </Layout>
  );
}
