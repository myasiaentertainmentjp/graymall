// src/pages/Editor.tsx
  import { useEffect, useMemo, useRef, useState } from 'react';
  import { useNavigate, useParams } from 'react-router-dom';
  import { ChevronLeft, Eye, Save, Send, MoreHorizontal, Trash2 } from 'lucide-react';

  import { supabase } from '../lib/supabase';
  import EnhancedRichTextEditor, { HeadingItem, RichTextEditorRef } from '../components/EnhancedRichTextEditor';
  import { TableOfContentsPanel } from '../components/TableOfContentsPanel';
  import ArticleSettingsPanel from '../components/ArticleSettingsPanel';

  type AffiliateTarget = 'all' | 'buyers';
  type AffiliateRate = 10 | 20 | 30 | 40 | 50;

  function htmlToPlainText(html: string) {
    if (!html) return '';
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return (tmp.textContent || tmp.innerText || '').replace(/\u00A0/g, ' ');
  }

  function cleanHtml(html: string) {
    return (html || '').trim();
  }

  function countTextChars(html: string) {
    return htmlToPlainText(html).length;
  }

  // 48時間をミリ秒で
  const FORTY_EIGHT_HOURS_MS = 48 * 60 * 60 * 1000;

  // BroadcastChannel名
  const PREVIEW_CHANNEL_NAME = 'graymall_preview';

  // paidContentが実質的に空かどうかを判定
  function isPaidContentEmpty(content: string): boolean {
    if (!content) return true;
    const trimmed = content.trim();
    if (!trimmed) return true;
    if (trimmed === '<p></p>' || trimmed === '<p><br></p>' || trimmed === '<p><br/></p>') return true;
    const text = htmlToPlainText(content).trim();
    return text.length === 0;
  }

  export default function Editor() {
    const { id: articleIdParam } = useParams();
    const navigate = useNavigate();
    const editorRef = useRef<RichTextEditorRef>(null);

    const articleId = useMemo(() => {
      if (!articleIdParam) return crypto.randomUUID();
      return articleIdParam === 'new' ? crypto.randomUUID() : articleIdParam;
    }, [articleIdParam]);

    const isNew = articleIdParam === 'new';

    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);

    const [title, setTitle] = useState<string>('');
    const [content, setContent] = useState<string>('');
    const [paidContent, setPaidContent] = useState<string>('');

    const [coverImageUrl, setCoverImageUrl] = useState<string | null>(null);

    const [isPaid, setIsPaid] = useState<boolean>(false);
    const [price, setPrice] = useState<number>(0);
    const [status, setStatus] = useState<'draft' | 'review' | 'published'>('draft');

    const [tags, setTags] = useState<string[]>([]);
    const [headings, setHeadings] = useState<HeadingItem[]>([]);

    // 有料エリア表示状態を販売設定(isPaid)から分離
    const [showPaidBoundary, setShowPaidBoundary] = useState<boolean>(false);

    // SP用メニュー表示状態
    const [spMenuOpen, setSpMenuOpen] = useState(false);

    // アフィリエイト関連
    const [affiliateEnabled, setAffiliateEnabled] = useState(false);
    const [affiliateTarget, setAffiliateTarget] = useState<AffiliateTarget | null>(null);
    const [affiliateRate, setAffiliateRate] = useState<AffiliateRate | null>(null);
    const [affiliateRateLastChangedAt, setAffiliateRateLastChangedAt] = useState<string | null>(null);
    const [originalAffiliateRate, setOriginalAffiliateRate] = useState<AffiliateRate | null>(null);
    const [affiliateRateError, setAffiliateRateError] = useState<string | null>(null);
    const [affiliateRateNextChangeAt, setAffiliateRateNextChangeAt] = useState<Date | null>(null);

    const paidEnabled = showPaidBoundary;

    const stats = useMemo(() => {
      const freeCharCount = countTextChars(content);
      const paidCharCount = showPaidBoundary ? countTextChars(paidContent) : 0;
      const freeImageCount = (content.match(/<img\b/gi) || []).length;
      const paidImageCount = showPaidBoundary ? (paidContent.match(/<img\b/gi) || []).length : 0;

      return {
        totalCharCount: freeCharCount + paidCharCount,
        totalImageCount: freeImageCount + paidImageCount,
        paidCharCount,
        paidImageCount,
      };
    }, [content, paidContent, showPaidBoundary]);

    useEffect(() => {
      let cancelled = false;

      (async () => {
        if (!articleIdParam || articleIdParam === 'new') return;

        setLoading(true);

        const { data, error } = await supabase.from('articles').select('*').eq('id', articleIdParam).single();

        if (cancelled) return;

        if (error) {
          console.error(error);
          setLoading(false);
          return;
        }

        setTitle(data?.title || '');

        const fullContent = data?.content || '';
        if (fullContent.includes('<!-- paid -->')) {
          const [free, paid] = fullContent.split('<!-- paid -->');
          setContent(free.trim());
          setPaidContent(paid.trim());
          setShowPaidBoundary(true);
        } else {
          setContent(fullContent);
          setPaidContent('');
          setShowPaidBoundary(false);
        }

        setCoverImageUrl(data?.cover_image_url || null);

        setIsPaid(Boolean(data?.has_partial_paywall));
        setPrice(Number(data?.price || 0));

        const dbStatus = data?.status;
        if (dbStatus === 'pending_review') {
          setStatus('review');
        } else if (dbStatus === 'published') {
          setStatus('published');
        } else {
          setStatus('draft');
        }

        setAffiliateEnabled(Boolean(data?.affiliate_enabled));
        setAffiliateTarget((data?.affiliate_target as AffiliateTarget) || null);
        const loadedRate = data?.affiliate_rate as AffiliateRate | null;
        setAffiliateRate(loadedRate);
        setOriginalAffiliateRate(loadedRate);
        setAffiliateRateLastChangedAt(data?.affiliate_rate_last_changed_at || null);

        setTags([]);

        setLoading(false);
      })();

      return () => {
        cancelled = true;
      };
    }, [articleIdParam]);

    const checkAffiliateRateChange = (newRate: AffiliateRate | null): boolean => {
      if (newRate === originalAffiliateRate) {
        setAffiliateRateError(null);
        setAffiliateRateNextChangeAt(null);
        return true;
      }

      if (!affiliateRateLastChangedAt) {
        setAffiliateRateError(null);
        setAffiliateRateNextChangeAt(null);
        return true;
      }

      const lastChanged = new Date(affiliateRateLastChangedAt);
      const now = new Date();
      const diff = now.getTime() - lastChanged.getTime();

      if (diff < FORTY_EIGHT_HOURS_MS) {
        const nextChangeAt = new Date(lastChanged.getTime() + FORTY_EIGHT_HOURS_MS);
        setAffiliateRateError('48時間以内に還元率を変更済みです');
        setAffiliateRateNextChangeAt(nextChangeAt);
        return false;
      }

      setAffiliateRateError(null);
      setAffiliateRateNextChangeAt(null);
      return true;
    };

    const validateBeforeSave = (): boolean => {
      if (affiliateEnabled && affiliateRate === null) {
        alert('紹介料の還元率を選択してください');
        return false;
      }

      if (affiliateEnabled && affiliateRate !== originalAffiliateRate) {
        if (!checkAffiliateRateChange(affiliateRate)) {
          return false;
        }
      }

      return true;
    };

    async function upsertArticle(nextStatus: 'draft' | 'review' | 'published') {
      if (!validateBeforeSave()) {
        return null;
      }

      setSaving(true);

      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        alert('ログインが必要です');
        setSaving(false);
        return null;
      }

      const dbStatus = nextStatus === 'review' ? 'pending_review' : nextStatus;

      // paidContentが実質的に存在する場合は常に保存
      const hasPaidContent = !isPaidContentEmpty(paidContent);
      const fullContent = hasPaidContent
        ? cleanHtml(content) + '\n<!-- paid -->\n' + cleanHtml(paidContent)
        : cleanHtml(content);

      const rateChanged = affiliateEnabled && affiliateRate !== originalAffiliateRate;

      const payload: Record<string, any> = {
        id: articleId,
        author_id: user.id,
        title: title.trim() || '無題',
        slug: articleId,
        excerpt: htmlToPlainText(content).slice(0, 200) || ' ',
        content: fullContent,
        cover_image_url: coverImageUrl || null,
        has_partial_paywall: isPaid,
        price: isPaid ? price : 0,
        status: dbStatus as 'draft' | 'pending_review' | 'published',
        updated_at: new Date().toISOString(),
        affiliate_enabled: affiliateEnabled,
        affiliate_target: affiliateEnabled ? affiliateTarget : null,
        affiliate_rate: affiliateEnabled ? affiliateRate : null,
      };

      if (rateChanged) {
        payload.affiliate_rate_last_changed_at = new Date().toISOString();
      }

      const { data, error } = await supabase.from('articles').upsert(payload).select().single();

      setSaving(false);

      if (error) {
        console.error(error);
        alert(error.message || '保存に失敗しました');
        return null;
      }

      if (affiliateEnabled) {
        setOriginalAffiliateRate(affiliateRate);
        if (rateChanged) {
          setAffiliateRateLastChangedAt(payload.affiliate_rate_last_changed_at);
        }
      }

      if (isNew) {
        navigate(`/editor/${data.id}`, { replace: true });
      }

      return data;
    }

    async function uploadThumbnail(file: File): Promise<string> {
      const safeName = (file.name || 'image').replace(/[^a-zA-Z0-9._-]+/g, '_');
      const path = `covers/${articleId}/${Date.now()}-${safeName}`;

      const { error: uploadError } = await supabase.storage
        .from('article-images')
        .upload(path, file, { upsert: true, contentType: file.type || 'image/*' });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage.from('article-images').getPublicUrl(path);
      const url = data?.publicUrl;
      if (!url) throw new Error('サムネイルURLの取得に失敗しました');

      return url;
    }

    async function saveDraft() {
      const result = await upsertArticle('draft');
      if (result) {
        alert('下書き保存されました');
      }
    }

    function openPreview() {
      const previewData = {
        title: title.trim() || '無題',
        content,
        paidContent,
        isPaid,
        price,
        coverImageUrl,
        tags,
      };

      const key = `preview_${articleId}`;

      try {
        localStorage.setItem(key, JSON.stringify(previewData));
      } catch (e) {
        console.warn('localStorage保存失敗:', e);
      }

      const url = `${window.location.origin}/preview/${articleId}`;
      window.open(url, '_blank');

      try {
        const channel = new BroadcastChannel(PREVIEW_CHANNEL_NAME);
        setTimeout(() => {
          channel.postMessage({ key, data: previewData });
          setTimeout(() => channel.close(), 2000);
        }, 300);
      } catch (e) {
        console.warn('BroadcastChannel送信失敗:', e);
      }
    }

    async function goToPublish() {
      const result = await upsertArticle('draft');
      if (!result) return;

      navigate(`/publish/${result.id}`);
    }

    // 記事削除
    async function handleDeleteArticle() {
      if (!articleIdParam || articleIdParam === 'new') {
        navigate('/my-articles');
        return;
      }

      const confirmed = window.confirm('この記事を削除しますか？この操作は取り消せません。');
      if (!confirmed) return;

      const { error } = await supabase.from('articles').delete().eq('id', articleIdParam);
      if (error) {
        alert('削除に失敗しました');
        return;
      }

      navigate('/my-articles');
    }

    function handleJumpToHeading(index: number) {
      editorRef.current?.scrollToHeadingIndex(index);
    }

    function handleChangeIsPaid(newIsPaid: boolean) {
      setIsPaid(newIsPaid);
    }

    // 要件1修正: 有料エリア削除時にpaidContentを保持
    // 要件2修正: カーソル位置以降を有料エリアに移動
    function handleTogglePaidBoundary(cursorContentAfter?: string) {
      setShowPaidBoundary((prev) => {
        const next = !prev;
        if (next) {
          // 有料エリアを表示する場合
          if (cursorContentAfter && cursorContentAfter.trim()) {
            // カーソル位置以降のコンテンツがある場合、それを有料エリアに移動
            setPaidContent(cursorContentAfter);
          } else if (isPaidContentEmpty(paidContent)) {
            // 既存の paidContent がなければ初期化
            setPaidContent('<p></p>');
          }
          // 既存の paidContent がある場合はそのまま保持
        }
        // 非表示にする場合、paidContentは絶対に消さない（保持）
        return next;
      });
    }

    const handleAffiliateRateChange = (rate: AffiliateRate) => {
      setAffiliateRate(rate);
      if (rate !== originalAffiliateRate) {
        checkAffiliateRateChange(rate);
      } else {
        setAffiliateRateError(null);
        setAffiliateRateNextChangeAt(null);
      }
    };

    // SPメニュー外クリックで閉じる
    useEffect(() => {
      const handleClickOutside = () => setSpMenuOpen(false);
      if (spMenuOpen) {
        document.addEventListener('click', handleClickOutside);
        return () => document.removeEventListener('click', handleClickOutside);
      }
    }, [spMenuOpen]);

    if (loading) {
      return <div className="min-h-[60vh] flex items-center justify-center text-gray-600">読み込み中...</div>;
    }

    const isSaveDisabled = saving || (affiliateRateError !== null);

    return (
      <div className="min-h-screen bg-white">
        <div className="border-b border-gray-200 bg-white sticky top-0 z-40">
          <div className="max-w-[1400px] mx-auto px-4 h-14 flex items-center justify-between gap-3">
            {/* 戻るボタン */}
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="inline-flex items-center gap-1 text-sm font-semibold text-gray-800"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden sm:inline">戻る</span>
            </button>

            {/* PC用ボタン */}
            <div className="hidden sm:flex items-center gap-2">
              <button
                type="button"
                onClick={saveDraft}
                disabled={isSaveDisabled}
                className="h-10 px-4 rounded-xl border border-gray-200 bg-white text-sm font-semibold text-gray-900 inline-flex items-center gap-2 disabled:opacity-60"
              >
                <Save className="w-4 h-4" />
                下書き保存
              </button>

              <button
                type="button"
                onClick={openPreview}
                disabled={saving}
                className="h-10 px-4 rounded-xl border border-gray-200 bg-white text-sm font-semibold text-gray-900 inline-flex items-center gap-2 disabled:opacity-60"
              >
                <Eye className="w-4 h-4" />
                プレビュー
              </button>

              <button
                type="button"
                onClick={goToPublish}
                disabled={isSaveDisabled}
                className="h-10 px-4 rounded-xl bg-slate-900 text-white text-sm font-semibold inline-flex items-center gap-2 disabled:opacity-60"
              >
                <Send className="w-4 h-4" />
                公開に進む
              </button>
            </div>

            {/* SP用ボタン（要件4修正） */}
            <div className="flex sm:hidden items-center gap-2">
              <button
                type="button"
                onClick={saveDraft}
                disabled={isSaveDisabled}
                className="h-9 px-3 rounded-lg border border-gray-200 bg-white text-xs font-semibold text-gray-900 disabled:opacity-60"
              >
                保存
              </button>

              <button
                type="button"
                onClick={goToPublish}
                disabled={isSaveDisabled}
                className="h-9 px-3 rounded-lg bg-slate-900 text-white text-xs font-semibold disabled:opacity-60"
              >
                公開
              </button>

              {/* 3点メニュー */}
              <div className="relative">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSpMenuOpen(!spMenuOpen);
                  }}
                  className="h-9 w-9 rounded-lg border border-gray-200 bg-white flex items-center justify-center"
                >
                  <MoreHorizontal className="w-5 h-5 text-gray-600" />
                </button>

                {spMenuOpen && (
                  <div className="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border border-gray-200 py-1 min-w-[140px] z-50">
                    <button
                      type="button"
                      onClick={() => {
                        setSpMenuOpen(false);
                        openPreview();
                      }}
                      className="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      プレビュー
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSpMenuOpen(false);
                        handleDeleteArticle();
                      }}
                      className="w-full px-4 py-2.5 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      削除
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-[1400px] mx-auto px-4 py-4">
          <div className="grid grid-cols-12 gap-4">
            <div className="hidden lg:block col-span-3">
              <div className="rounded-2xl border border-gray-200 bg-white p-3">
                <div className="text-sm font-semibold text-gray-900 mb-3">目次</div>
                <TableOfContentsPanel
                  headings={headings}
                  onJump={handleJumpToHeading}
                />

                {/* ヘルプリンク */}
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <a
                    href="/guidelines"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-gray-500 hover:text-gray-700 underline"
                  >
                    ガイドライン
                  </a>
                </div>
              </div>
            </div>

            <div className="col-span-12 lg:col-span-6">
              <div className="bg-white p-4">
                <textarea
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="記事タイトル"
                  rows={1}
                  className="w-full text-3xl font-extrabold outline-none placeholder:text-gray-300 resize-none overflow-hidden"
                  style={{ minHeight: '2.5rem' }}
                  onInput={(e) => {
                    const target = e.target as HTMLTextAreaElement;
                    target.style.height = 'auto';
                    target.style.height = target.scrollHeight + 'px';
                  }}
                />

                <div className="mt-4">
                  <EnhancedRichTextEditor
                    ref={editorRef}
                    articleId={articleId}
                    content={content}
                    paidContent={paidContent}
                    paidEnabled={paidEnabled}
                    onChangeContent={setContent}
                    onChangePaidContent={setPaidContent}
                    onHeadingsChange={setHeadings}
                    onTogglePaid={handleTogglePaidBoundary}
                  />
                </div>
              </div>
            </div>

            <div className="hidden lg:block col-span-3">
              <div className="rounded-2xl border border-gray-200 bg-white p-4">
                <div className="text-sm font-semibold text-gray-900 mb-3">記事設定</div>

                <ArticleSettingsPanel
                  thumbnailUrl={coverImageUrl || null}
                  onChangeThumbnail={setCoverImageUrl}
                  isPaid={isPaid}
                  onChangeIsPaid={handleChangeIsPaid}
                  price={price}
                  onChangePrice={setPrice}
                  tags={tags}
                  onChangeTags={setTags}
                  status={status}
                  onChangeStatus={setStatus}
                  stats={stats}
                  onUploadThumbnail={uploadThumbnail}
                  affiliateEnabled={affiliateEnabled}
                  onChangeAffiliateEnabled={setAffiliateEnabled}
                  affiliateTarget={affiliateTarget}
                  onChangeAffiliateTarget={setAffiliateTarget}
                  affiliateRate={affiliateRate}
                  onChangeAffiliateRate={handleAffiliateRateChange}
                  affiliateRateError={affiliateRateError}
                  affiliateRateNextChangeAt={affiliateRateNextChangeAt}
                  showPaidBoundary={showPaidBoundary}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
