// src/pages/Home.tsx
import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';
import { ChevronRight, ChevronDown } from 'lucide-react';
import ArticleCard from '../components/ArticleCard';
import AdSlot from '../components/AdSlot';
import { Link } from 'react-router-dom';

type Category = Database['public']['Tables']['categories']['Row'];

type Article = Database['public']['Tables']['articles']['Row'] & {
  users?: { display_name: string | null; email: string; avatar_url?: string | null };
  primary_category?: { id: string; name: string; slug: string } | null;
  sub_category?: { id: string; name: string; slug: string } | null;
};

// Ad banners - hardcoded for launch, can be DB later
// 表示サイズ: 224×224px、入稿推奨: 448×448px (Retina対応)
const AD_BANNERS = [
  { id: 'ad-1', image_url: null, link_url: null, alt_text: '広告1' },
  { id: 'ad-2', image_url: null, link_url: null, alt_text: '広告2' },
  { id: 'ad-3', image_url: null, link_url: null, alt_text: '広告3' },
];

export default function Home() {
  const [parentCategories, setParentCategories] = useState<Category[]>([]);
  const [subCategories, setSubCategories] = useState<Record<string, Category[]>>({});
  const [popularArticles, setPopularArticles] = useState<Article[]>([]);
  const [newArticles, setNewArticles] = useState<Article[]>([]);
  const [editorPickArticles, setEditorPickArticles] = useState<Article[]>([]);
  const [categoryArticles, setCategoryArticles] = useState<Record<string, Article[]>>({});
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);

    try {
      // Load categories
      const { data: cats } = await supabase
        .from('categories')
        .select('*')
        .order('sort_order');

      if (cats) {
        const parents = cats.filter(c => !c.parent_id);
        const subs: Record<string, Category[]> = {};
        parents.forEach(p => {
          subs[p.id] = cats.filter(c => c.parent_id === p.id);
        });
        setParentCategories(parents);
        setSubCategories(subs);
        // デフォルトで全カテゴリを展開
        setExpandedCategories(new Set(parents.map(p => p.id)));
      }

      // Load published articles with author info
      const { data: articles } = await supabase
        .from('articles')
        .select(`
          *,
          users:author_id (display_name, email, avatar_url),
          primary_category:primary_category_id (id, name, slug),
          sub_category:sub_category_id (id, name, slug)
        `)
        .eq('status', 'published')
        .eq('is_archived', false)
        .order('published_at', { ascending: false })
        .limit(100);

      if (articles) {
        const allArticles = articles as Article[];

        // Load admin-configured sections
        const { data: sections } = await supabase
          .from('homepage_sections')
          .select('*')
          .eq('is_active', true);

        const sectionMap: Record<string, string[]> = {};
        if (sections) {
          for (const section of sections) {
            const { data: sectionArticles } = await supabase
              .from('homepage_section_articles')
              .select('article_id')
              .eq('section_id', section.id)
              .order('display_order');
            if (sectionArticles) {
              sectionMap[section.section_key] = sectionArticles.map(sa => sa.article_id);
            }
          }
        }

        // Popular - use admin-configured or fall back to recent
        if (sectionMap['popular']?.length) {
          const ids = sectionMap['popular'];
          setPopularArticles(
            ids.map(id => allArticles.find(a => a.id === id)).filter(Boolean) as Article[]
          );
        } else {
          setPopularArticles(allArticles.slice(0, 7));
        }

        // New articles - always use most recent
        setNewArticles(allArticles.slice(0, 8));

        // Editor picks - use admin-configured or fall back
        if (sectionMap['editor_picks']?.length) {
          const ids = sectionMap['editor_picks'];
          setEditorPickArticles(
            ids.map(id => allArticles.find(a => a.id === id)).filter(Boolean) as Article[]
          );
        } else {
          setEditorPickArticles(allArticles.slice(0, 4));
        }

        // Group by parent category
        const catArts: Record<string, Article[]> = {};
        (cats || []).filter(c => !c.parent_id).forEach(cat => {
          catArts[cat.id] = allArticles
            .filter(a => a.primary_category_id === cat.id)
            .slice(0, 4);
        });
        setCategoryArticles(catArts);
      }
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleCategory = (catId: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(catId)) {
        next.delete(catId);
      } else {
        next.add(catId);
      }
      return next;
    });
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-6">
          {/* Left Sidebar */}
          <aside className="hidden lg:block w-56 flex-shrink-0">
            {/* Ad Banners - 表示: 224×224px、入稿推奨: 448×448px */}
            <div className="space-y-3 mb-6">
              {AD_BANNERS.map(ad => (
                <AdSlot
                  key={ad.id}
                  id={ad.id}
                  imageUrl={ad.image_url}
                  linkUrl={ad.link_url}
                  altText={ad.alt_text}
                />
              ))}
            </div>

            {/* Category List - 枠線なし */}
            <div className="p-2">
              <nav className="space-y-2">
                {parentCategories.map(cat => (
                  <div key={cat.id}>
                    <button
                      onClick={() => toggleCategory(cat.id)}
                      className="w-full flex items-center justify-between px-2 py-1.5 text-sm font-medium text-gray-800 hover:text-gray-900"
                    >
                      <span>{cat.name}</span>
                      <ChevronDown
                        className={`w-4 h-4 text-gray-400 transition-transform ${
                          expandedCategories.has(cat.id) ? '' : '-rotate-90'
                        }`}
                      />
                    </button>
                    {expandedCategories.has(cat.id) && subCategories[cat.id] && (
                      <div className="ml-2 mt-1 space-y-0.5">
                        {subCategories[cat.id].map(sub => (
                          <Link
                            key={sub.id}
                            to={`/articles?category=${sub.slug}`}
                            className="block px-2 py-1.5 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded"
                          >
                            {sub.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1 min-w-0">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-gray-600">読み込み中...</div>
              </div>
            ) : (
              <div className="space-y-10">
                {/* Popular Articles - 統一サイズ */}
                <section>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-gray-900">人気の記事</h2>
                    <Link
                      to="/articles?sort=popular"
                      className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1"
                    >
                      もっと見る <ChevronRight className="w-4 h-4" />
                    </Link>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {popularArticles.slice(0, 8).map((article, idx) => (
                      <ArticleCard key={article.id} article={article} rank={idx + 1} />
                    ))}
                  </div>
                </section>

                {/* New Articles */}
                <section>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-gray-900">新着記事</h2>
                    <Link
                      to="/articles?sort=new"
                      className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1"
                    >
                      もっと見る <ChevronRight className="w-4 h-4" />
                    </Link>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {newArticles.map(article => (
                      <ArticleCard key={article.id} article={article} />
                    ))}
                  </div>
                </section>

                {/* Editor Picks */}
                {editorPickArticles.length > 0 && (
                  <section>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-bold text-gray-900">編集部おすすめ</h2>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {editorPickArticles.map(article => (
                        <ArticleCard key={article.id} article={article} />
                      ))}
                    </div>
                  </section>
                )}

                {/* Category Pickups */}
                {parentCategories.map(cat => {
                  const articles = categoryArticles[cat.id] || [];
                  if (articles.length === 0) return null;
                  return (
                    <section key={cat.id}>
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-bold text-gray-900">{cat.name}</h2>
                        <Link
                          to={`/articles?category=${cat.slug}`}
                          className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1"
                        >
                          もっと見る <ChevronRight className="w-4 h-4" />
                        </Link>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {articles.map(article => (
                          <ArticleCard key={article.id} article={article} />
                        ))}
                      </div>
                    </section>
                  );
                })}
              </div>
            )}
          </main>
        </div>
      </div>
    </Layout>
  );
}
