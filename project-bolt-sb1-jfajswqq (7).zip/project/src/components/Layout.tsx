import { ReactNode, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { User, Menu, X } from 'lucide-react';
import Footer from './Footer';
import NotificationDropdown from './NotificationDropdown';
import PostDropdown from './PostDropdown';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/signin');
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <Link to="/" className="flex items-center gap-2">
                <span className="text-2xl font-bold text-gray-900">GrayMall</span>
              </Link>

              <nav className="hidden md:flex items-center gap-6">
                <Link to="/" className="text-gray-700 hover:text-gray-900 text-sm font-medium">
                  ホーム
                </Link>
                <Link to="/articles" className="text-gray-700 hover:text-gray-900 text-sm font-medium">
                  記事一覧
                </Link>
                {user && (
                  <Link to="/me/articles" className="text-gray-700 hover:text-gray-900 text-sm font-medium">
                    自分の記事
                  </Link>
                )}
                {profile?.can_publish && (
                  <Link to="/dashboard" className="text-gray-700 hover:text-gray-900 text-sm font-medium">
                    ダッシュボード
                  </Link>
                )}
                {profile?.is_admin && (
                  <Link to="/admin" className="text-gray-700 hover:text-gray-900 text-sm font-medium">
                    管理画面
                  </Link>
                )}
              </nav>
            </div>

            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <div className="hidden md:flex items-center gap-3">
                    <NotificationDropdown />
                    <PostDropdown />

                    <div className="relative group">
                      <button className="flex items-center gap-2 p-2 text-gray-600 hover:text-gray-900" type="button">
                        <User className="w-5 h-5" />
                      </button>
                      <div className="absolute right-0 pt-2 w-48 hidden group-hover:block">
                        <div className="bg-white rounded-lg shadow-lg border border-gray-200 py-2">
                          <Link to={`/users/${user.id}`} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                            マイページ
                          </Link>
                          {profile?.can_publish && (
                            <Link to="/dashboard" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                              売上管理
                            </Link>
                          )}
                          <Link to="/settings" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                            設定
                          </Link>
                          <div className="border-t border-gray-100 my-1"></div>
                          <button
                            onClick={handleSignOut}
                            className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                            type="button"
                          >
                            サインアウト
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <button
                    className="md:hidden p-2 text-gray-600"
                    onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    type="button"
                  >
                    {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                  </button>
                </>
              ) : (
                <div className="flex items-center gap-3">
                  <Link to="/signin" className="text-gray-700 hover:text-gray-900 text-sm font-medium">
                    サインイン
                  </Link>
                  <Link to="/signup" className="bg-gray-900 text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition text-sm font-medium">
                    新規登録
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>

        {mobileMenuOpen && user && (
          <div className="md:hidden border-t border-gray-200 bg-white">
            <div className="px-4 py-3 space-y-3">
              <Link to="/" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                ホーム
              </Link>
              <Link to="/articles" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                記事一覧
              </Link>
              <Link to="/me/articles" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                自分の記事
              </Link>
              <Link to="/editor/new" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                記事を投稿
              </Link>
              {profile?.can_publish && (
                <Link to="/dashboard" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                  ダッシュボード
                </Link>
              )}
              {profile?.is_admin && (
                <Link to="/admin" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                  管理画面
                </Link>
              )}
              <Link to={`/users/${user?.id}`} className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                マイページ
              </Link>
              {profile?.can_publish && (
                <Link to="/dashboard" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                  売上管理
                </Link>
              )}
              <Link to="/settings" className="block text-gray-700 hover:text-gray-900 text-sm font-medium" onClick={() => setMobileMenuOpen(false)}>
                設定
              </Link>
              <button
                onClick={() => {
                  handleSignOut();
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-left text-gray-700 hover:text-gray-900 text-sm font-medium"
                type="button"
              >
                サインアウト
              </button>
            </div>
          </div>
        )}
      </header>

      <main className="bg-white">{children}</main>

      <Footer />
    </div>
  );
}
